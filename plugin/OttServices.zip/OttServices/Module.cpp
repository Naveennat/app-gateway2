#include "Module.h"

// The Thunder plugins typically include a module declaration for build reference.
MODULE_NAME_DECLARATION(BUILD_REFERENCE)
