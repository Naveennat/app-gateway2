/*
 * If not stated otherwise in this file or this component's LICENSE file the
 * following copyright and licenses apply:
 *
 * Copyright 2025 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#pragma once

#include "mfr_temperature.h"

class mfrImpl
{
    public:
        virtual mfrError_t mfrGetTempThresholds(int*high, int*critical) = 0;
        virtual mfrError_t mfrSetTempThresholds(int tempHigh, int tempCritical) = 0;
        virtual mfrError_t mfrGetTemperature(mfrTemperatureState_t* curState, int* curTemperature, int* wifiTemperature) = 0;

        virtual ~mfrImpl() = default;
};

class mfr
{
protected:
    static mfrImpl* impl;
public:
    mfr();
    mfr(const mfr &obj) = delete; // deleted copy constructor so that copy of the instance cannot be created.
    static void setImpl(mfrImpl* newImpl);

    static mfrError_t mfrGetTempThresholds(int*high, int*critical);
    static mfrError_t mfrSetTempThresholds(int tempHigh, int tempCritical);
    static mfrError_t mfrGetTemperature(mfrTemperatureState_t* curState, int* curTemperature, int* wifiTemperature);
};
