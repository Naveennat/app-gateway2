#pragma once
#ifndef MODULE_NAME
#define MODULE_NAME Plugin_FbCommon
#endif

#include <plugins/plugins.h>
#include <tracing/tracing.h>

#undef EXTERNAL
#define EXTERNAL
