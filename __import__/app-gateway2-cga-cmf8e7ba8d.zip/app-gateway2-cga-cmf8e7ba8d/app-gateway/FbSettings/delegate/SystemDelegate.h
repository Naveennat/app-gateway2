 /**
  * If not stated otherwise in this file or this component's LICENSE
  * file the following copyright and licenses apply:
  *
  * Copyright 2020 RDK Management
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  * http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  **/

 #pragma once

 #include <memory>
 #include <string>
 #include <unordered_set>
 #include <unordered_map>
 #include <chrono>
 #include <cctype>
 #include <cstdio>

 #include <plugins/plugins.h>
 #include "UtilsLogging.h"
 #include "UtilsJsonrpcDirectLink.h"
 #include "ThunderUtils.h"
 #include "BaseEventDelegate.h"

 // Define a callsign constant to match the AUTHSERVICE_CALLSIGN-style pattern.
 #ifndef SYSTEM_CALLSIGN
 #define SYSTEM_CALLSIGN "org.rdk.System"
 #endif

 #ifndef DISPLAYSETTINGS_CALLSIGN
 #define DISPLAYSETTINGS_CALLSIGN "org.rdk.DisplaySettings"
 #endif

 #ifndef HDCPPROFILE_CALLSIGN
 #define HDCPPROFILE_CALLSIGN "org.rdk.HdcpProfile"
 #endif

 class SystemDelegate : public BaseEventDelegate
 {
 public:

     // Event names exposed by this delegate (consumer subscriptions may vary in case)
     static constexpr const char* EVENT_ON_VIDEO_RES_CHANGED   = "device.onVideoResolutionChanged";
     static constexpr const char* EVENT_ON_SCREEN_RES_CHANGED  = "device.onScreenResolutionChanged";
     static constexpr const char* EVENT_ON_HDR_CHANGED         = "device.onHdrChanged";
     static constexpr const char* EVENT_ON_HDCP_CHANGED        = "device.onHdcpChanged";

     SystemDelegate(PluginHost::IShell *shell, WPEFramework::Exchange::IAppNotifications* appNotifications)
         : BaseEventDelegate(appNotifications)
         , _shell(shell)
         , _subscriptions()
         , _displayRpc(nullptr)
         , _hdcpRpc(nullptr)
         , _displaySubscribed(false)
         , _hdcpSubscribed(false)
     {
         // Proactively subscribe to underlying Thunder events so we can react quickly.
         // Actual dispatch to apps only happens if registrations exist (BaseEventDelegate check).
         SetupDisplaySettingsSubscription();
         SetupHdcpProfileSubscription();
     }

     ~SystemDelegate()
     {
         // Cleanup subscriptions
         try {
             if (_displayRpc && _displaySubscribed) {
                 _displayRpc->Unsubscribe(2000, _T("resolutionChanged"));
             }
             if (_hdcpRpc && _hdcpSubscribed) {
                 _hdcpRpc->Unsubscribe(2000, _T("onDisplayConnectionChanged"));
             }
         } catch (...) {
             // Safe-guard against destructor exceptions
         }
         _displayRpc.reset();
         _hdcpRpc.reset();
         _shell = nullptr;
     }

     // PUBLIC_INTERFACE
     Core::hresult GetDeviceMake(std::string &make)
     {
         /** Retrieve the device make using org.rdk.System.getDeviceInfo */
         LOGINFO("GetDeviceMake FbSettings Delegate");
         make.clear();
         auto link = AcquireLink();
         if (!link)
         {
             make = "unknown";
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("getDeviceInfo", params, response);
         if (rc == Core::ERROR_NONE)
         {
             if (response.HasLabel(_T("make")))
             {
                 make = response[_T("make")].String();
             }
         }

         if (make.empty())
         {
             // Per transform: return_or_else(.result.make, "unknown")
             make = "unknown";
         }
         // Wrap in quotes to make it a valid JSON string
         make = "\"" + make + "\"";
         return Core::ERROR_NONE;
     }

     // PUBLIC_INTERFACE
     Core::hresult GetDeviceName(std::string &name)
     {
         /** Retrieve the friendly name using org.rdk.System.getFriendlyName */
         name.clear();
         auto link = AcquireLink();
         if (!link)
         {
             name = "Living Room";
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("getFriendlyName", params, response);
         if (rc == Core::ERROR_NONE && response.HasLabel(_T("friendlyName")))
         {
             name = response[_T("friendlyName")].String();
         }

         // Default if empty
         if (name.empty())
         {
             name = "Living Room";
         }
         // Wrap in quotes to make it a valid JSON string
         name = "\"" + name + "\"";
         return Core::ERROR_NONE;
     }

     // PUBLIC_INTERFACE
     Core::hresult SetDeviceName(const std::string &name)
     {
         /** Set the friendly name using org.rdk.System.setFriendlyName */
         auto link = AcquireLink();
         if (!link)
         {
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         params[_T("friendlyName")] = name;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("setFriendlyName", params, response);
         if (rc == Core::ERROR_NONE && response.HasLabel(_T("success")) && response[_T("success")].Boolean())
         {
             return Core::ERROR_NONE;
         }
         LOGERR("SystemDelegate: couldn't set name");
         return Core::ERROR_GENERAL;
     }

     // PUBLIC_INTERFACE
     Core::hresult GetDeviceSku(std::string &skuOut)
     {
         /** Retrieve the device SKU from org.rdk.System.getSystemVersions.stbVersion */
         skuOut.clear();
         auto link = AcquireLink();
         if (!link)
         {
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("getSystemVersions", params, response);
         if (rc != Core::ERROR_NONE)
         {
             LOGERR("SystemDelegate: getSystemVersions failed rc=%u", rc);
             return Core::ERROR_UNAVAILABLE;
         }
         if (!response.HasLabel(_T("stbVersion")))
         {
             LOGERR("SystemDelegate: getSystemVersions missing stbVersion");
             return Core::ERROR_UNAVAILABLE;
         }

         const std::string stbVersion = response[_T("stbVersion")].String();
         // Per transform: split("_")[0]
         auto pos = stbVersion.find('_');
         skuOut = (pos == std::string::npos) ? stbVersion : stbVersion.substr(0, pos);
         if (skuOut.empty())
         {
             LOGERR("SystemDelegate: Failed to get SKU");
             return Core::ERROR_UNAVAILABLE;
         }
         // Wrap in quotes to make it a valid JSON string
         skuOut = "\"" + skuOut + "\"";
         return Core::ERROR_NONE;
     }

     Core::hresult GetFirmwareVersion(std::string &version)
     {
         mAdminLock.Lock();
         version = mVersionResponse;
         mAdminLock.Unlock();

         if (!version.empty()) {
             return Core::ERROR_NONE;
         }

         auto link = AcquireLink();
         if (!link)
         {
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("getSystemVersions", params, response);
         if (rc != Core::ERROR_NONE)
         {
             LOGERR("SystemDelegate: getSystemVersions failed rc=%u", rc);
             return Core::ERROR_UNAVAILABLE;
         }
         if (!response.HasLabel(_T("receiverVersion"))) {
             LOGERR("SystemDelegate: getSystemVersions missing receiverVersion");
             return Core::ERROR_UNAVAILABLE;
         }
         std::string receiverVersion = response[_T("receiverVersion")].String();
         if (receiverVersion.empty())
         {
             LOGERR("SystemDelegate: Failed to get Version");
             return Core::ERROR_UNAVAILABLE;
         }

         std::string stbVersion = response[_T("stbVersion")].String();
         if (stbVersion.empty())
         {
             LOGERR("SystemDelegate: Failed to get STB Version");
             return Core::ERROR_UNAVAILABLE;
         }

         // receiver version is typically in 99.99.15.07 format need to set extract the first three parts only for major.minor.patch
         // if receiverversion is not in number format return error
         uint32_t major;
         uint32_t minor;
         uint32_t patch;

         if (sscanf(receiverVersion.c_str(), "%u.%u.%u", &major, &minor, &patch) != 3)
         {
             LOGERR("SystemDelegate: receiverVersion is not in number format");
             return Core::ERROR_UNAVAILABLE;
         }

         JsonObject versionObj;
         JsonObject api;
         api["major"] = 1;
         api["minor"] = 7;
         api["patch"] = 0;
         api["readable"] = "Firebolt API v1.7.0";

         JsonObject firmwareInfo;
         firmwareInfo["major"] = major;
         firmwareInfo["minor"] = minor;
         firmwareInfo["patch"] = patch;
         firmwareInfo["readable"] = stbVersion;
         // Build this json data structure {"api":{"major":1,"minor":7,"patch":0,"readable":"Firebolt API v1.7.0"},"firmware":{"major":99,"minor":99,"patch":15,"readable":"SKXI11ADS_MIDDLEWARE_DEV_develop_20251101123542_TEST_CD"},"os":{"major":99,"minor":99,"patch":15,"readable":"SKXI11ADS_MIDDLEWARE_DEV_develop_20251101123542_TEST_CD"},"debug":"4.0.0"}
         versionObj["api"] = api;
         versionObj["firmware"] = firmwareInfo;
         versionObj["os"] = firmwareInfo;
         versionObj["debug"] = "4.0.0";

         mAdminLock.Lock();
         versionObj.ToString(mVersionResponse);
         version = mVersionResponse;
         mAdminLock.Unlock();

         return Core::ERROR_NONE;
     }

     // PUBLIC_INTERFACE
     Core::hresult GetCountryCode(std::string &code)
     {
         /** Retrieve Firebolt country code derived from org.rdk.System.getTerritory */
         code.clear();
         auto link = AcquireLink();
         if (!link)
         {
             code = "US";
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("getTerritory", params, response);
         if (rc == Core::ERROR_NONE && response.HasLabel(_T("territory")))
         {
             const std::string terr = response[_T("territory")].String();
             code = TerritoryThunderToFirebolt(terr, "US");
         }
         if (code.empty())
         {
             code = "US";
         }
         // Wrap in quotes to make it a valid JSON string
         code = "\"" + code + "\"";
         return Core::ERROR_NONE;
     }

     // PUBLIC_INTERFACE
     Core::hresult SetCountryCode(const std::string &code)
     {
         /** Set territory using org.rdk.System.setTerritory mapped from Firebolt country code */
         auto link = AcquireLink();
         if (!link)
         {
             return Core::ERROR_UNAVAILABLE;
         }

         const std::string territory = TerritoryFireboltToThunder(code, "USA");
         WPEFramework::Core::JSON::VariantContainer params;
         params[_T("territory")] = territory;

         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("setTerritory", params, response);
         if (rc == Core::ERROR_NONE && response.HasLabel(_T("success")) && response[_T("success")].Boolean())
         {
             return Core::ERROR_NONE;
         }
         LOGERR("SystemDelegate: couldn't set countrycode");
         return Core::ERROR_GENERAL;
     }

     // PUBLIC_INTERFACE
     Core::hresult GetTimeZone(std::string &tz)
     {
         /** Retrieve timezone using org.rdk.System.getTimeZoneDST */
         tz.clear();
         auto link = AcquireLink();
         if (!link)
         {
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("getTimeZoneDST", params, response);
         if (rc == Core::ERROR_NONE && response.HasLabel(_T("success")) && response[_T("success")].Boolean())
         {
             if (response.HasLabel(_T("timeZone")))
             {
                 tz = response[_T("timeZone")].String();
                 // Wrap in quotes to make it a valid JSON string
                 tz = "\"" + tz + "\"";
                 return Core::ERROR_NONE;
             }
         }
         LOGERR("SystemDelegate: couldn't get timezone");
         return Core::ERROR_UNAVAILABLE;
     }

     // PUBLIC_INTERFACE
     Core::hresult SetTimeZone(const std::string &tz)
     {
         /** Set timezone using org.rdk.System.setTimeZoneDST */
         auto link = AcquireLink();
         if (!link)
         {
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         params[_T("timeZone")] = tz;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("setTimeZoneDST", params, response);
         if (rc == Core::ERROR_NONE && response.HasLabel(_T("success")) && response[_T("success")].Boolean())
         {
             return Core::ERROR_NONE;
         }
         LOGERR("SystemDelegate: couldn't set timezone");
         return Core::ERROR_GENERAL;
     }

     // PUBLIC_INTERFACE
     Core::hresult GetSecondScreenFriendlyName(std::string &name)
     {
         /** Alias to GetDeviceName using org.rdk.System.getFriendlyName */
         return GetDeviceName(name);
     }

     // PUBLIC_INTERFACE
     Core::hresult GetScreenResolution(std::string &jsonArray)
     {
         /**
          * Get [w, h] screen resolution using DisplaySettings.getCurrentResolution.
          * Returns "[1920,1080]" as fallback when unavailable.
          */
         jsonArray = "[1920,1080]";
         auto link = AcquireLink();
         if (!link) {
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("getCurrentResolution", params, response);
         if (rc != Core::ERROR_NONE) {
             return Core::ERROR_GENERAL;
         }

         int w = 1920, h = 1080;

         // Try top-level first
         if (response.HasLabel(_T("w")) && response.HasLabel(_T("h"))) {
             auto wv = response.Get(_T("w"));
             auto hv = response.Get(_T("h"));
             if (wv.Content() == WPEFramework::Core::JSON::Variant::type::NUMBER &&
                 hv.Content() == WPEFramework::Core::JSON::Variant::type::NUMBER) {
                 w = static_cast<int>(wv.Number());
                 h = static_cast<int>(hv.Number());
             }
         } else if (response.HasLabel(_T("result"))) {
             // Try nested "result"
             auto r = response.Get(_T("result"));
             if (r.Content() == WPEFramework::Core::JSON::Variant::type::OBJECT) {
                 auto wnv = r.Object().Get(_T("w"));
                 auto hnv = r.Object().Get(_T("h"));
                 auto wdv = r.Object().Get(_T("width"));
                 auto hdv = r.Object().Get(_T("height"));

                 if (wnv.Content() == WPEFramework::Core::JSON::Variant::type::NUMBER &&
                     hnv.Content() == WPEFramework::Core::JSON::Variant::type::NUMBER) {
                     w = static_cast<int>(wnv.Number());
                     h = static_cast<int>(hnv.Number());
                 } else if (wdv.Content() == WPEFramework::Core::JSON::Variant::type::NUMBER &&
                            hdv.Content() == WPEFramework::Core::JSON::Variant::type::NUMBER) {
                     w = static_cast<int>(wdv.Number());
                     h = static_cast<int>(hdv.Number());
                 }
             }
         }

         jsonArray = "[" + std::to_string(w) + "," + std::to_string(h) + "]";
         LOGDBG("[FbSettings|ScreenResolutionChanged] Computed screenResolution: w=%d h=%d -> %s", w, h, jsonArray.c_str());
         return Core::ERROR_NONE;
     }

     // PUBLIC_INTERFACE
     Core::hresult GetVideoResolution(std::string &jsonArray)
     {
         /**
          * Get [w, h] video resolution. Prefer DisplaySettings.getCurrentResolution width
          * to infer UHD vs FHD; else default to 1080p.
          * This is a stubbed approximation of the /system/hdmi.uhdConfigured logic.
          */
         std::string sr;
         (void)GetScreenResolution(sr);
         // sr expected format: "[w,h]"
         int w = 1920, h = 1080;
         if (sr.size() > 2 && sr.front() == '[' && sr.back() == ']') {
             try {
                 // Simple parsing without heavy JSON dependencies
                 auto comma = sr.find(',');
                 if (comma != std::string::npos) {
                     int sw = std::stoi(sr.substr(1, comma - 1));
                     int sh = std::stoi(sr.substr(comma + 1, sr.size() - comma - 2));
                     if (sw >= 3840 || sh >= 2160) {
                         w = 3840; h = 2160;
                     } else {
                         w = 1920; h = 1080;
                     }
                     LOGDBG("[FbSettings|VideoResolutionChanged] Transform screen(%d x %d) -> video(%d x %d)", sw, sh, w, h);
                 }
             } catch (...) {
                 // keep defaults
                 LOGDBG("[FbSettings|VideoResolutionChanged] Transform parse error for %s -> using defaults (%d x %d)", sr.c_str(), w, h);
             }
         }
         jsonArray = "[" + std::to_string(w) + "," + std::to_string(h) + "]";
         return Core::ERROR_NONE;
     }

     // PUBLIC_INTERFACE
     Core::hresult GetHdcp(std::string &jsonObject)
     {
         /**
          * Get HDCP status via HdcpProfile.getHDCPStatus.
          * Return {"hdcp1.4":bool,"hdcp2.2":bool} with sensible defaults.
          */
         jsonObject = "{\"hdcp1.4\":false,\"hdcp2.2\":false}";
         auto link = AcquireLink();
         if (!link) {
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("getHDCPStatus", params, response);
         if (rc != Core::ERROR_NONE) {
             return Core::ERROR_GENERAL;
         }

         bool hdcp14 = false;
         bool hdcp22 = false;

         // Prefer nested "result" if available
         if (response.HasLabel(_T("result"))) {
             auto r = response.Get(_T("result"));
             if (r.Content() == WPEFramework::Core::JSON::Variant::type::OBJECT) {
                 auto succ = r.Object().Get(_T("success"));
                 auto status = r.Object().Get(_T("HDCPStatus"));
                 if (succ.Content() == WPEFramework::Core::JSON::Variant::type::BOOLEAN && succ.Boolean() &&
                     status.Content() == WPEFramework::Core::JSON::Variant::type::OBJECT) {
                     auto reason = status.Object().Get(_T("hdcpReason"));
                     auto version = status.Object().Get(_T("currentHDCPVersion"));
                     if (reason.Content() == WPEFramework::Core::JSON::Variant::type::NUMBER &&
                         static_cast<int>(reason.Number()) == 2 &&
                         version.Content() == WPEFramework::Core::JSON::Variant::type::STRING) {
                         const std::string v = version.String();
                         if (v == "1.4") { hdcp14 = true; }
                         else { hdcp22 = true; }
                     }
                 }
             }
         } else {
             // Fallback: try top-level fields if present
             auto status = response.Get(_T("HDCPStatus"));
             if (status.Content() == WPEFramework::Core::JSON::Variant::type::OBJECT) {
                 auto reason = status.Object().Get(_T("hdcpReason"));
                 auto version = status.Object().Get(_T("currentHDCPVersion"));
                 if (reason.Content() == WPEFramework::Core::JSON::Variant::type::NUMBER &&
                     static_cast<int>(reason.Number()) == 2 &&
                     version.Content() == WPEFramework::Core::JSON::Variant::type::STRING) {
                     const std::string v = version.String();
                     if (v == "1.4") { hdcp14 = true; }
                     else { hdcp22 = true; }
                 }
             }
         }

         jsonObject = std::string("{\"hdcp1.4\":") + (hdcp14 ? "true" : "false")
                    + ",\"hdcp2.2\":" + (hdcp22 ? "true" : "false") + "}";
         LOGDBG("[FbSettings|HdcpChanged] Computed HDCP flags: hdcp1.4=%s hdcp2.2=%s -> %s",
                hdcp14 ? "true" : "false", hdcp22 ? "true" : "false", jsonObject.c_str());
         return Core::ERROR_NONE;
     }

     // PUBLIC_INTERFACE
     Core::hresult GetHdr(std::string &jsonObject)
     {
         /**
          * Retrieve HDR capability/state via DisplaySettings.getTVHDRCapabilities.
          * Returns object with hdr10, dolbyVision, hlg, hdr10Plus flags (defaults false).
          */
         jsonObject = "{\"hdr10\":false,\"dolbyVision\":false,\"hlg\":false,\"hdr10Plus\":false}";
         auto link = AcquireLink();
         if (!link) {
             return Core::ERROR_UNAVAILABLE;
         }

         WPEFramework::Core::JSON::VariantContainer params;
         WPEFramework::Core::JSON::VariantContainer response;
         const uint32_t rc = link->Invoke("getTVHDRCapabilities", params, response);
         if (rc != Core::ERROR_NONE) {
             return Core::ERROR_GENERAL;
         }

         bool hdr10 = false, dv = false, hlg = false, hdr10plus = false;

         auto parseCaps = [&](const WPEFramework::Core::JSON::Variant& vobj) {
             if (vobj.Content() == WPEFramework::Core::JSON::Variant::type::OBJECT) {
                 auto hdmi = vobj.Object().Get(_T("hdmi"));
                 if (hdmi.Content() == WPEFramework::Core::JSON::Variant::type::OBJECT) {
                     auto sinkHDR10 = hdmi.Object().Get(_T("sinkHDR10"));
                     auto sinkDolbyVision = hdmi.Object().Get(_T("sinkDolbyVision"));
                     auto sinkHLG = hdmi.Object().Get(_T("sinkHLG"));
                     auto sinkHDR10Plus = hdmi.Object().Get(_T("sinkHDR10Plus"));
                     hdr10    = (sinkHDR10.Content() == WPEFramework::Core::JSON::Variant::type::BOOLEAN) ? sinkHDR10.Boolean() : false;
                     dv       = (sinkDolbyVision.Content() == WPEFramework::Core::JSON::Variant::type::BOOLEAN) ? sinkDolbyVision.Boolean() : false;
                     hlg      = (sinkHLG.Content() == WPEFramework::Core::JSON::Variant::type::BOOLEAN) ? sinkHLG.Boolean() : false;
                     hdr10plus= (sinkHDR10Plus.Content() == WPEFramework::Core::JSON::Variant::type::BOOLEAN) ? sinkHDR10Plus.Boolean() : false;
                 }
             }
         };

         if (response.HasLabel(_T("result"))) {
             auto r = response.Get(_T("result"));
             parseCaps(r);
         } else {
             parseCaps(response);
         }

         jsonObject = std::string("{\"hdr10\":") + (hdr10 ? "true" : "false")
                    + ",\"dolbyVision\":" + (dv ? "true" : "false")
                    + ",\"hlg\":" + (hlg ? "true" : "false")
                    + ",\"hdr10Plus\":" + (hdr10plus ? "true" : "false") + "}";
         LOGDBG("[FbSettings|HdrChanged] Computed HDR flags: hdr10=%s dolbyVision=%s hlg=%s hdr10Plus=%s -> %s",
                hdr10 ? "true" : "false",
                dv ? "true" : "false",
                hlg ? "true" : "false",
                hdr10plus ? "true" : "false",
                jsonObject.c_str());
         return Core::ERROR_NONE;
     }

     // ---- Event exposure (Emit helpers) ----

     // PUBLIC_INTERFACE
     bool EmitOnVideoResolutionChanged()
     {
         std::string payload;
         if (GetVideoResolution(payload) != Core::ERROR_NONE) {
             LOGERR("[FbSettings|VideoResolutionChanged] handler=GetVideoResolution failed to compute payload");
             return false;
         }
         // Transform to rpcv2_event wrapper: { "videoResolution": $event_handler_response }
         const std::string wrapped = std::string("{\"videoResolution\":") + payload + "}";
         LOGINFO("[FbSettings|VideoResolutionChanged] Final rpcv2_event payload=%s", wrapped.c_str());
         if (this->ShouldEmitDebounced(EVENT_ON_VIDEO_RES_CHANGED, wrapped)) {
             LOGDBG("[FbSettings|VideoResolutionChanged] Emitting event: %s", EVENT_ON_VIDEO_RES_CHANGED);
             this->Dispatch(EVENT_ON_VIDEO_RES_CHANGED, wrapped);
             return true;
         }
         LOGDBG("[FbSettings|VideoResolutionChanged] Debounced/dropped");
         return false;
     }

     // PUBLIC_INTERFACE
     bool EmitOnScreenResolutionChanged()
     {
         std::string payload;
         if (GetScreenResolution(payload) != Core::ERROR_NONE) {
             LOGERR("[FbSettings|ScreenResolutionChanged] handler=GetScreenResolution failed to compute payload");
             return false;
         }
         // Transform to rpcv2_event wrapper: { "screenResolution": $event }
         const std::string wrapped = std::string("{\"screenResolution\":") + payload + "}";
         LOGINFO("[FbSettings|ScreenResolutionChanged] Final rpcv2_event payload=%s", wrapped.c_str());
         if (this->ShouldEmitDebounced(EVENT_ON_SCREEN_RES_CHANGED, wrapped)) {
             LOGDBG("[FbSettings|ScreenResolutionChanged] Emitting event: %s", EVENT_ON_SCREEN_RES_CHANGED);
             this->Dispatch(EVENT_ON_SCREEN_RES_CHANGED, wrapped);
             return true;
         }
         LOGDBG("[FbSettings|ScreenResolutionChanged] Debounced/dropped");
         return false;
     }

     // PUBLIC_INTERFACE
     bool EmitOnHdcpChanged()
     {
         std::string payload;
         if (GetHdcp(payload) != Core::ERROR_NONE) {
             LOGERR("[FbSettings|HdcpChanged] handler=GetHdcp failed to compute payload");
             return false;
         }
         LOGINFO("[FbSettings|HdcpChanged] Final rpcv2_event payload=%s", payload.c_str());
         if (this->ShouldEmitDebounced(EVENT_ON_HDCP_CHANGED, payload)) {
             LOGDBG("[FbSettings|HdcpChanged] Emitting event: %s", EVENT_ON_HDCP_CHANGED);
             this->Dispatch(EVENT_ON_HDCP_CHANGED, payload);
             return true;
         }
         LOGDBG("[FbSettings|HdcpChanged] Debounced/dropped");
         return false;
     }

     // PUBLIC_INTERFACE
     bool EmitOnHdrChanged()
     {
         std::string payload;
         if (GetHdr(payload) != Core::ERROR_NONE) {
             LOGERR("[FbSettings|HdrChanged] handler=GetHdr failed to compute payload");
             return false;
         }
         LOGINFO("[FbSettings|HdrChanged] Final rpcv2_event payload=%s", payload.c_str());
         if (this->ShouldEmitDebounced(EVENT_ON_HDR_CHANGED, payload)) {
             LOGDBG("[FbSettings|HdrChanged] Emitting event: %s", EVENT_ON_HDR_CHANGED);
             this->Dispatch(EVENT_ON_HDR_CHANGED, payload);
             return true;
         }
         LOGDBG("[FbSettings|HdrChanged] Debounced/dropped");
         return false;
     }

     // ---- AppNotifications registration hook ----
     // Called by SettingsDelegate when app subscribes/unsubscribes to events.
     bool HandleEvent(const std::string &event, const bool listen, bool &registrationError) override
     {
         registrationError = false;

         const std::string evLower = ToLower(event);

         // Supported events (case-insensitive)
         if (evLower == "device.onvideoresolutionchanged"
             || evLower == "device.onscreenresolutionchanged"
             || evLower == "device.onhdcpchanged"
             || evLower == "device.onhdrchanged")
         {
             LOGINFO("[FbSettings|EventRegistration] event=%s listen=%s", event.c_str(), listen ? "true" : "false");
             if (listen) {
                 this->AddNotification(event);
                 // Ensure underlying Thunder subscriptions are active
                 SetupDisplaySettingsSubscription();
                 SetupHdcpProfileSubscription();
                 registrationError = true; // indicate handled without error
                 return true;
             } else {
                 this->RemoveNotification(event);
                 registrationError = true;
                 return true;
             }
         }
         return false;
     }


 private:
     inline std::shared_ptr<WPEFramework::Utils::JSONRPCDirectLink> AcquireLink() const
     {
         // Create a direct JSON-RPC link to the Thunder System plugin using the Supporting_Files helper.
         if (_shell == nullptr)
         {
             LOGERR("SystemDelegate: shell is null");
             return nullptr;
         }
         return WPEFramework::Utils::GetThunderControllerClient(_shell, SYSTEM_CALLSIGN);
     }

     // Minimal, scoped debounce helper to suppress duplicate emissions within a short interval.
     inline bool ShouldEmitDebounced(const std::string& event, const std::string& payload) const
     {
         using Clock = std::chrono::steady_clock;
         static std::unordered_map<std::string, std::pair<std::string, Clock::time_point>> s_last;
         static constexpr int kDefaultDebounceMs = 150;

         const auto now = Clock::now();
         auto it = s_last.find(event);
         if (it == s_last.end()) {
             s_last.emplace(event, std::make_pair(payload, now));
             return true;
         }

         const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - it->second.second).count();
         if (elapsed < kDefaultDebounceMs && it->second.first == payload) {
             return false;
         }

         it->second.first = payload;
         it->second.second = now;
         return true;
     }

     static std::string ToLower(const std::string &in)
     {
         std::string out;
         out.reserve(in.size());
         for (char c : in)
         {
             out.push_back(static_cast<char>(::tolower(static_cast<unsigned char>(c))));
         }
         return out;
     }

     static std::string TerritoryThunderToFirebolt(const std::string &terr, const std::string &deflt)
     {
         if (EqualsIgnoreCase(terr, "USA"))
             return "US";
         if (EqualsIgnoreCase(terr, "CAN"))
             return "CA";
         if (EqualsIgnoreCase(terr, "ITA"))
             return "IT";
         if (EqualsIgnoreCase(terr, "GBR"))
             return "GB";
         if (EqualsIgnoreCase(terr, "IRL"))
             return "IE";
         if (EqualsIgnoreCase(terr, "AUS"))
             return "AU";
         if (EqualsIgnoreCase(terr, "AUT"))
             return "AT";
         if (EqualsIgnoreCase(terr, "CHE"))
             return "CH";
         if (EqualsIgnoreCase(terr, "DEU"))
             return "DE";
         return deflt;
     }

     static std::string TerritoryFireboltToThunder(const std::string &code, const std::string &deflt)
     {
         if (EqualsIgnoreCase(code, "US"))
             return "USA";
         if (EqualsIgnoreCase(code, "CA"))
             return "CAN";
         if (EqualsIgnoreCase(code, "IT"))
             return "ITA";
         if (EqualsIgnoreCase(code, "GB"))
             return "GBR";
         if (EqualsIgnoreCase(code, "IE"))
             return "IRL";
         if (EqualsIgnoreCase(code, "AU"))
             return "AUS";
         if (EqualsIgnoreCase(code, "AT"))
             return "AUT";
         if (EqualsIgnoreCase(code, "CH"))
             return "CHE";
         if (EqualsIgnoreCase(code, "DE"))
             return "DEU";
         return deflt;
     }

     static bool EqualsIgnoreCase(const std::string &a, const std::string &b)
     {
         if (a.size() != b.size())
             return false;
         for (size_t i = 0; i < a.size(); ++i)
         {
             if (::tolower(static_cast<unsigned char>(a[i])) != ::tolower(static_cast<unsigned char>(b[i])))
             {
                 return false;
             }
         }
         return true;
     }
     // Setup subscriptions to underlying Thunder plugin events
     void SetupDisplaySettingsSubscription()
     {
         if (_displaySubscribed) return;
         try {
             if (!_displayRpc) {
                 _displayRpc = ThunderUtils::getThunderControllerClient(DISPLAYSETTINGS_CALLSIGN);
             }
             if (_displayRpc) {
                 const uint32_t status = _displayRpc->Subscribe<WPEFramework::Core::JSON::VariantContainer>(
                     2000, _T("resolutionChanged"), &SystemDelegate::OnDisplaySettingsResolutionChanged, this);
                 if (status == Core::ERROR_NONE) {
                     LOGINFO("SystemDelegate: Subscribed to %s.resolutionChanged", DISPLAYSETTINGS_CALLSIGN);
                     _displaySubscribed = true;
                 } else {
                     LOGERR("SystemDelegate: Failed to subscribe to %s.resolutionChanged rc=%u", DISPLAYSETTINGS_CALLSIGN, status);
                 }
             }
         } catch (...) {
             LOGERR("SystemDelegate: exception during DisplaySettings subscription");
         }
     }

     void SetupHdcpProfileSubscription()
     {
         if (_hdcpSubscribed) return;
         try {
             if (!_hdcpRpc) {
                 _hdcpRpc = ThunderUtils::getThunderControllerClient(HDCPPROFILE_CALLSIGN);
             }
             if (_hdcpRpc) {
                 const uint32_t status = _hdcpRpc->Subscribe<WPEFramework::Core::JSON::VariantContainer>(
                     2000, _T("onDisplayConnectionChanged"), &SystemDelegate::OnHdcpProfileDisplayConnectionChanged, this);
                 if (status == Core::ERROR_NONE) {
                     LOGINFO("SystemDelegate: Subscribed to %s.onDisplayConnectionChanged", HDCPPROFILE_CALLSIGN);
                     _hdcpSubscribed = true;
                 } else {
                     LOGERR("SystemDelegate: Failed to subscribe to %s.onDisplayConnectionChanged rc=%u", HDCPPROFILE_CALLSIGN, status);
                 }
             }
         } catch (...) {
             LOGERR("SystemDelegate: exception during HdcpProfile subscription");
         }
     }

     // Event handlers invoked by Thunder JSON-RPC subscription
     void OnDisplaySettingsResolutionChanged(const WPEFramework::Core::JSON::VariantContainer& params)
     {
         (void)params;
         LOGINFO("[FbSettings|DisplaySettings.resolutionChanged] Incoming alias=%s.%s, invoking handlers...",
                 DISPLAYSETTINGS_CALLSIGN, "resolutionChanged");
         // Re-query state and dispatch debounced events
         const bool screenEmitted = EmitOnScreenResolutionChanged();
         const bool videoEmitted = EmitOnVideoResolutionChanged();
         LOGINFO("[FbSettings|DisplaySettings.resolutionChanged] Handler responses: onScreenResolutionChanged=%s onVideoResolutionChanged=%s",
                 screenEmitted ? "emitted" : "skipped", videoEmitted ? "emitted" : "skipped");
     }

     void OnHdcpProfileDisplayConnectionChanged(const WPEFramework::Core::JSON::VariantContainer& params)
     {
         (void)params;
         LOGINFO("[FbSettings|HdcpProfile.onDisplayConnectionChanged] Incoming alias=%s.%s, invoking handlers...",
                 HDCPPROFILE_CALLSIGN, "onDisplayConnectionChanged");
         // Re-query state and dispatch debounced events
         const bool hdcpEmitted = EmitOnHdcpChanged();
         const bool hdrEmitted = EmitOnHdrChanged();
         LOGINFO("[FbSettings|HdcpProfile.onDisplayConnectionChanged] Handler responses: onHdcpChanged=%s onHdrChanged=%s",
                 hdcpEmitted ? "emitted" : "skipped", hdrEmitted ? "emitted" : "skipped");
     }

 private:
     PluginHost::IShell *_shell;
     std::unordered_set<std::string> _subscriptions;
     mutable Core::CriticalSection mAdminLock;
     std::string mVersionResponse;

     // JSONRPC clients for event subscriptions
     std::shared_ptr<WPEFramework::JSONRPC::LinkType<WPEFramework::Core::JSON::IElement>> _displayRpc;
     std::shared_ptr<WPEFramework::JSONRPC::LinkType<WPEFramework::Core::JSON::IElement>> _hdcpRpc;
     bool _displaySubscribed;
     bool _hdcpSubscribed;
 };
