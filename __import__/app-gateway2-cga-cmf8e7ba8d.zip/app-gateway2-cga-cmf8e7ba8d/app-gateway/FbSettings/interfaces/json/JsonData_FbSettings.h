#pragma once

/*
 * Minimal placeholder for Thunder generated JsonData_FbSettings interfaces.
 * The FbSettings.cpp translation unit only requires the presence of this header.
 *
 * If needed in the future, populate with the generated JSON structures.
 */

namespace WPEFramework {
namespace Exchange {
namespace JsonData {
namespace FbSettings {
// Intentionally left empty.
} // namespace FbSettings
} // namespace JsonData
} // namespace Exchange
} // namespace WPEFramework
